package com.example.macstudent.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends WearableActivity implements View.OnClickListener {


    Button btnSubmit;

    DBHelper dbHelper;
    SQLiteDatabase thunderDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        btnSubmit = (Button) findViewById(R.id.register);
        btnSubmit.setOnClickListener(this);
        Log.e("RegisterActivity", "Calling DBHElper");
        dbHelper = new DBHelper(this);

        if (dbHelper != null) {
            Log.e("RegisterActivity", "dbhelper is not null");
        }



    }

    @Override
    public void onClick(View v) {

        if (v.getId() == btnSubmit.getId()) {

            insertUser();
           // displayData();
            Intent registerIntent = new Intent
                    (this, MainActivity.class);
            startActivity(registerIntent);


        }


    }
    private void insertUser(){
        EditText edtName = (EditText) findViewById(R.id.editText);
        EditText edtage = (EditText) findViewById(R.id.editText4);
        EditText edtaddress = (EditText) findViewById(R.id.editText3);
        EditText edtPassword = (EditText) findViewById(R.id.editText2);


        String name = edtName.getText().toString();
        String age = edtage.getText().toString();
        String address = edtaddress.getText().toString();

        String password = edtPassword.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Age", age);
        cv.put("Address" , address);
        cv.put("Password", password);

        try{
            thunderDB = dbHelper.getWritableDatabase();
            thunderDB.insert("UserInfo",
                    null, cv);
            Log.v("Insert record","Successful");

        }catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        thunderDB.close();
    }

}
